"""
main.py
Entry point for Music Tagger.
"""

import socket
import sys

from PySide6.QtWidgets import QApplication

from ui.main_window import MainWindow
from ui.styles import TAN_STYLESHEET

# musicbrainzngs and pyacoustid don't accept an explicit per-call timeout —
# they fall back to Python's global socket default, which is otherwise
# unbounded. Without this, a single slow/stalled connection can hang far
# longer than expected (musicbrainzngs' own rate limiter compounds this
# further, since it counts the full response wait as part of its
# 1-request-per-second pacing — see
# https://github.com/alastair/python-musicbrainzngs/issues/204). 30s is
# generous enough for a genuinely slow but working MusicBrainz response
# while still failing fast on a truly stalled connection.
socket.setdefaulttimeout(30)


def main():
    app = QApplication(sys.argv)
    app.setStyleSheet(TAN_STYLESHEET)

    window = MainWindow()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
